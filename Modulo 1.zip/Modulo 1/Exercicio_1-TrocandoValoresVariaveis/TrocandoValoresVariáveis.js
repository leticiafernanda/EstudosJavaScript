let a = 'vermelho';
let b = 'azul';
let x = a;
a=b;
b=x;
console.log(a);
console.log(b);