let valorMax = maxValor(10,80);
console.log(valorMax);

function maxValor(n1,n2)
{
    return n1>n2 ? n1:n2;
}