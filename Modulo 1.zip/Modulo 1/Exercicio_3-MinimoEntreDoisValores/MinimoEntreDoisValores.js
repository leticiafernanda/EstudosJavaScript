let valorMin = minValor(10,80);
console.log(valorMin);

function minValor(n1,n2)
{
    return n1<n2 ? n1:n2;
}