let valorMedio = mediaValor(10,80);
console.log(valorMedio);

function medioValor(n1,n2)
{
    return n1+n2/2;
}